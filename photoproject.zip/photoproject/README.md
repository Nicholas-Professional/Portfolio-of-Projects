# Photo Project #
* Project Information: Photography development. Customers upload an image, select the size of the image, then the image is printed and shipped to their door. 

## Tasks ##
1. Create a preview method to edit the website 
2. Create a way for users to create an account
3. Create a way to upload an image from user computer
4. Create a way to select an image size from 5 by 7 to 44 by 100 inches
5. Create a contact page for issues with orders
6. Create an About Me page that allows the creator to edit the text
7. Take in the users' information, such as Name, E-mail, Address, and Phone Number
8. Implement some sort of method that allows users to pay through Paypal 

## Help ##
* Refer to the links.txt file for some helpful tutorials.
